Note, the band and QA files are renamed copies of the C1 data. Use these files for metadata testing only.
